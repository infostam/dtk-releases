# Change Log

All notable changes will be documented in this file.
 
## [Unreleased]
 
### Added

- Support for Rohde & Schwarz ROMES PC app file (.sqc, .rscmd) to pcapng converting
- Support for including payload (data) packets beside signaling packet from
  - Qtrun NSG/AirScreen file
  - R&S QualiPoc/ROMES file

### Changed

### Fixed

## [1.8] - 2024-12-27
 
### Added

- Overall source code optimization and cleanup

### Changed
 
### Fixed

- Execution path handling based on absolute path (#18)

## [1.7] - 2024-12-19
 
### Added

- Keyboard shorcuts

### Changed
 
### Fixed

- Execution path handling based on absolute path (#18)

## [1.6] - 2024-12-12
 
### Added

- New "Download" button in "Check for Updates" popup window (#15)
- License expiry reminder popup window within the last month
- Setting for license expiry reminder in "General Settings" (#16)

### Changed

- Overall source code restructuring
- Enhancement for .ini file content handling (#16)
 
### Fixed

## [1.5] - 2024-12-06
 
### Added

- New feature: "Check for Updates"

### Changed

- General Settings under "License"
- Enhancement for .ini file hanndling
- Updating standalone showerror popup cases
 
### Fixed

## [1.4] - 2024-12-01
 
### Added

- Support for Rohde & Schwarz QualiPoc app file (.sqz, .mf) to pcapng converting

### Changed

- Qualcomm packet datetime considers timezone (#11)
 
### Fixed

## [1.3] - 2024-11-29
 
### Added

### Changed

- Rewamp code structure and compilation
 
### Fixed

- License status message was incorrect is some cases (#8)
- Close Splash window earlier (#9)
- Error Window was not always on top (#10)

## [1.2] - 2024-11-25
 
### Added

- Packet Converter supports the following message types:
  - NR 5G RRC and NAS OTA (Over The Air)
  - LTE RRC and NAS OTA
  - WCDMA RRC OTA
  - UMTS UE OTA (NAS not supported)
  - (2G: GSM RR Signaling - not supported)
- Support for Qtrun NSG Android app log file (.log and .log.gz) to pcapng converting
- Support for Qtrun AirScreen PC app exported text file to pcapng converting

### Changed
 
### Fixed

## [1.1] - 2024-11-18
 
### Added

- Version number handling improvement (#1)
- Packet Converter improvements

### Changed
 
### Fixed

- One image name and reference was corrected (#2)

## [1.0] - 2024-10-31
 
### Added

- First released version of dtk

### Changed
 
### Fixed
